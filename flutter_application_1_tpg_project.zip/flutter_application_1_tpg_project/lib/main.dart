import 'package:flutter/material.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';

void main() {
  runApp(const MyApp());
}

class UserProfile {
  String firstName;
  String lastName;
  String email;
  String phone;
  String role;
  String programmingLanguage;
  File? profileImage;

  UserProfile({
    this.firstName = 'Kodisang',
    this.lastName = 'Maloka',
    this.email = 'codymaloka320@gmail.com',
    this.phone = '081 349 1280 ',
    this.role = 'Software Developer',
    this.programmingLanguage = 'C#, Dart, JavaScript,Python',
    this.profileImage,
  });

  UserProfile.copy(UserProfile other)
      : firstName = other.firstName,
        lastName = other.lastName,
        email = other.email,
        phone = other.phone,
        role = other.role,
        programmingLanguage = other.programmingLanguage,
        profileImage = other.profileImage;
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Profile Manager',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const ProfilePage(),
    );
  }
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late UserProfile userProfile;
  bool isEditing = false;

  @override
  void initState() {
    super.initState();
    userProfile = UserProfile();
  }

  void _startEditing() {
    setState(() {
      isEditing = true;
    });
  }

  void _cancelEditing() {
    setState(() {
      isEditing = false;
    });
  }

  void _saveChanges(UserProfile editedProfile) {
    setState(() {
      userProfile = editedProfile;
      isEditing = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile Manager'),
        centerTitle: true,
        elevation: 0,
      ),
      body: isEditing
          ? EditProfilePage(
              userProfile: userProfile,
              onSave: _saveChanges,
              onCancel: _cancelEditing,
            )
          : ViewProfilePage(
              userProfile: userProfile,
              onEditPressed: _startEditing,
            ),
    );
  }
}

class ViewProfilePage extends StatelessWidget {
  final UserProfile userProfile;
  final VoidCallback onEditPressed;

  const ViewProfilePage({
    super.key,
    required this.userProfile,
    required this.onEditPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 20),
              // Profile Avatar
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.deepPurple.withOpacity(0.3),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: CircleAvatar(
                  radius: 80,
                  backgroundColor: Colors.deepPurple.shade100,
                  backgroundImage: userProfile.profileImage != null
                      ? FileImage(userProfile.profileImage!)
                      : null,
                  child: userProfile.profileImage == null
                      ? Icon(
                          Icons.person,
                          size: 80,
                          color: Colors.deepPurple.shade400,
                        )
                      : null,
                ),
              ),
              const SizedBox(height: 30),
              // Name
              Text(
                '${userProfile.firstName} ${userProfile.lastName}',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              // Role
              Text(
                userProfile.role,
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: const Color.fromARGB(255, 81, 131, 224),
                      fontWeight: FontWeight.w600,
                    ),
              ),
              const SizedBox(height: 30),
              // Info Cards
              _buildInfoCard(
                context,
                Icons.email,
                'Email',
                userProfile.email,
              ),
              const SizedBox(height: 12),
              _buildInfoCard(
                context,
                Icons.phone,
                'Phone',
                userProfile.phone,
              ),
              const SizedBox(height: 12),
              _buildInfoCard(
                context,
                Icons.code,
                'Programming Language',
                userProfile.programmingLanguage,
              ),
              const SizedBox(height: 40),
              // Edit Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: onEditPressed,
                  icon: const Icon(Icons.edit),
                  label: const Text('Edit Profile'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    backgroundColor: const Color.fromARGB(255, 50, 127, 163),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoCard(
    BuildContext context,
    IconData icon,
    String label,
    String value,
  ) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.deepPurple.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                icon,
                color: Colors.deepPurple,
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.grey.shade600,
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class EditProfilePage extends StatefulWidget {
  final UserProfile userProfile;
  final Function(UserProfile) onSave;
  final VoidCallback onCancel;

  const EditProfilePage({
    super.key,
    required this.userProfile,
    required this.onSave,
    required this.onCancel,
  });

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late TextEditingController _firstNameController;
  late TextEditingController _lastNameController;
  late TextEditingController _emailController;
  late TextEditingController _phoneController;
  late TextEditingController _roleController;
  late TextEditingController _programmingLanguageController;
  late UserProfile _editedProfile;

  @override
  void initState() {
    super.initState();
    _editedProfile = UserProfile.copy(widget.userProfile);
    _firstNameController = TextEditingController(text: _editedProfile.firstName);
    _lastNameController = TextEditingController(text: _editedProfile.lastName);
    _emailController = TextEditingController(text: _editedProfile.email);
    _phoneController = TextEditingController(text: _editedProfile.phone);
    _roleController = TextEditingController(text: _editedProfile.role);
    _programmingLanguageController = TextEditingController(
      text: _editedProfile.programmingLanguage,
    );
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _roleController.dispose();
    _programmingLanguageController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? pickedFile = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );

    if (pickedFile != null) {
      setState(() {
        _editedProfile.profileImage = File(pickedFile.path);
      });
    }
  }

  void _removeImage() {
    setState(() {
      _editedProfile.profileImage = null;
    });
  }

  void _saveProfile() {
    _editedProfile.firstName = _firstNameController.text.trim();
    _editedProfile.lastName = _lastNameController.text.trim();
    _editedProfile.email = _emailController.text.trim();
    _editedProfile.phone = _phoneController.text.trim();
    _editedProfile.role = _roleController.text.trim();
    _editedProfile.programmingLanguage =
        _programmingLanguageController.text.trim();

    widget.onSave(_editedProfile);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            const SizedBox(height: 20),
            // Profile Image Section
            Stack(
              alignment: Alignment.bottomRight,
              children: [
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color.fromARGB(255, 18, 37, 207).withOpacity(0.3),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: CircleAvatar(
                    radius: 80,
                    backgroundColor: Colors.deepPurple.shade100,
                    backgroundImage:
                        _editedProfile.profileImage != null
                            ? FileImage(_editedProfile.profileImage!)
                            : null,
                    child: _editedProfile.profileImage == null
                        ? Icon(
                            Icons.person,
                            size: 80,
                            color: const Color.fromARGB(255, 190, 41, 41),
                          )
                        : null,
                  ),
                ),
                GestureDetector(
                  onTap: _pickImage,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.deepPurple,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.camera_alt,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                ),
              ],
            ),
            if (_editedProfile.profileImage != null) ...[
              const SizedBox(height: 12),
              TextButton.icon(
                onPressed: _removeImage,
                icon: const Icon(Icons.delete),
                label: const Text('Remove Image'),
                style: TextButton.styleFrom(
                  foregroundColor: const Color.fromARGB(255, 31, 168, 60),
                ),
              ),
            ],
            const SizedBox(height: 30),
            // Form Fields
            _buildTextField(
              controller: _firstNameController,
              label: 'First Name',
              icon: Icons.person,
            ),
            const SizedBox(height: 16),
            _buildTextField(
              controller: _lastNameController,
              label: 'Last Name',
              icon: Icons.person,
            ),
            const SizedBox(height: 16),
            _buildTextField(
              controller: _emailController,
              label: 'Email Address',
              icon: Icons.email,
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            _buildTextField(
              controller: _phoneController,
              label: 'Phone Number',
              icon: Icons.phone,
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 16),
            _buildTextField(
              controller: _roleController,
              label: 'Role',
              icon: Icons.work,
            ),
            const SizedBox(height: 16),
            _buildTextField(
              controller: _programmingLanguageController,
              label: 'Programming Language',
              icon: Icons.code,
            ),
            const SizedBox(height: 40),
            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: widget.onCancel,
                    icon: const Icon(Icons.close),
                    label: const Text('Cancel'),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      side: const BorderSide(color: Colors.deepPurple),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: _saveProfile,
                    icon: const Icon(Icons.save),
                    label: const Text('Save Changes'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      backgroundColor: const Color.fromARGB(255, 56, 99, 194),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: const Color.fromARGB(255, 56, 173, 20)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(
            color: Colors.deepPurple,
            width: 2,
          ),
        ),
        filled: true,
        fillColor: Colors.grey.shade50,
      ),
    );
  }
}
